import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent {
  user: User = {
    id: 0,  // Инициализация id (например, значением 0 или undefined)
    firstName: '',
    lastName: '',
    email: ''
  };

  constructor(private userService: UserService,
    private router: Router) { }

  saveUser(){
    this.userService.createUser(this.user).subscribe(data =>{
      console.log(data);
      this.goToUserList();
    },
    error => console.log(error));

  }

  goToUserList(){
    this.router.navigate(['/users'])
  }

  onSubmit() {
    if (this.user.firstName && this.user.lastName && this.user.email) {
      this.userService.createUser(this.user).subscribe(response => {
        console.log('User created:', response);
        this.user = { id: 0, firstName: '', lastName: '', email: '' };
      }, error => {
        console.error('Error creating user:', error);
      });
    } else {
      console.error('Form is incomplete');
    }
  }
  
}
